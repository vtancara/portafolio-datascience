import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.FSDataOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter; 
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

public class AnalisisRiesgo {
    public static void main(String[] args) {
        try {
            
            Configuration conf = new Configuration();
            URI uriNameNode = new URI("hdfs://namenode:9000");
            FileSystem fs = FileSystem.get(uriNameNode, conf);
            
            Path rutaEntrada = new Path("/user/root/datos/ventas_internacionales.csv");
            Path rutaSalida = new Path("/user/root/datos/resumen_ventas.csv");
            
            BufferedReader lector = new BufferedReader(new InputStreamReader(fs.open(rutaEntrada)));
            
            Map<String, Double> matrizAgrupada = new HashMap<>();
            
            String linea;
            lector.readLine();
            
            while ((linea = lector.readLine()) != null) {
                String[] atributos = linea.split(",");
                if (atributos.length >= 3) {
                    try {
                        String pais = atributos[3];
                        int cantidad = Integer.parseInt(atributos[1]);
                        double precio = Double.parseDouble(atributos[2]);
                        double monto = cantidad * precio;

                        matrizAgrupada.put(pais, matrizAgrupada.getOrDefault(pais, 0.0) + monto);
                    } catch (NumberFormatException e) {

                    }
                }
            }
            lector.close();
            

            FSDataOutputStream flujoSalida = fs.create(rutaSalida, true);
            BufferedWriter escritor = new BufferedWriter(new OutputStreamWriter(flujoSalida));
            
            escritor.write("pais,monto_total\n");
            
            for (Map.Entry<String, Double> registro : matrizAgrupada.entrySet()) {
                escritor.write(registro.getKey() + "," + registro.getValue() + "\n");
            }
            
            escritor.close();
            fs.close();
            
            System.out.println("Procesamiento y reduccion dimensional finalizados con exito.");
            
        } catch (Exception e) {
            System.err.println("Error critico de entrada o salida: " + e.getMessage());
        }
    }
}